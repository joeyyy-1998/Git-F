const HBuilderProcessId = process.env.HBuilderProcessId
if (HBuilderProcessId) {
	setInterval(() => {
		try {
			process.kill(HBuilderProcessId, 0);
		} catch (ex) {
			try {
				process.kill(process.pid, 'SIGKILL')
			} catch (e) {}
		}
	}, 3000);
}